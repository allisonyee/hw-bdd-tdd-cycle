require 'spec_helper'

describe MoviesController, :type => :controller do
  describe 'creating a movie' do
    it 'should create a new movie' do
      post :create, :movie => {:title => 'Movie'}
      expect(response).to redirect_to(movies_path)
    end
  end
  describe 'deleting a movie' do
    it 'should delete a new movie' do
      movie = Movie.create!(:id => 1)
      delete :destroy, :id => 1
      expect(response).to redirect_to(movies_path)
    end
  end
  describe 'sorting movies' do
    it 'should display movies in alphabetical order' do
    end
  end
  describe 'find movies with same director' do
    it 'should call the model method that finds movies with same director, if a director exists' do
      results = [double('movie1'), double('movie2')]
      movie = Movie.new(:director => 'George Lucas')
      movie.should_receive(:find_same_director).and_return(results)
      movie.find_same_director
    end
    it 'should redirect to movies page if no director' do
      # movie = Movie.new(:id => 123, :title => 'Nameless')
      get :find_with_same_director, :id => 123
      expect(response).to redirect_to movies_path
    end
  end
end